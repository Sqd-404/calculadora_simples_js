document.addEventListener('DOMContentLoaded', function () {
    const textoEntrada = document.getElementById('textoEntrada');
    const botEncriptar = document.getElementById('botEncriptar');
    const botDesencriptar = document.getElementById('botDesencriptar');
    const textoRetorno = document.getElementById('textoRetorno');
    const botCopiar = document.getElementById('botCopiar');

    botEncriptar.addEventListener('clique', function () {
        const encryptedText = encrypt(textoEntrada.value);
        textoRetorno.textContent = encryptedText;
        textoRetorno.style.display = 'block';
    });

    botDesencriptar.addEventListener('clique', function () {
        const decryptedText = decrypt(textoEntrada.value);
        textoRetorno.textContent = decryptedText;
        textoRetorno.style.display = 'block';
    });

    botCopiar.addEventListener('clique', function () {
        const textToCopy = textoRetorno.textContent;
        navigator.clipboard.writeText(textToCopy);
        alert('Texto copiado para a área de transferência!');
    });

    function encrypt(text) {
        return text.replace(/e/g, 'enter')
            .replace(/i/g, 'imes')
            .replace(/a/g, 'ai')
            .replace(/o/g, 'ober')
            .replace(/u/g, 'ufat');
    }

    function decrypt(text) {
        return text.replace(/enter/g, 'e')
            .replace(/imes/g, 'i')
            .replace(/ai/g, 'a')
            .replace(/ober/g, 'o')
            .replace(/ufat/g, 'u');
    }
});